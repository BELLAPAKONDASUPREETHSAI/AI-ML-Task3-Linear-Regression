
# Task 3: Linear Regression - House Price Prediction Dataset

## 🎯 Objective
Implement and understand simple & multiple linear regression using sklearn and evaluate model performance.

## 🛠 Tools Used
- Python
- Pandas
- Scikit-learn
- Matplotlib

## 📌 Steps Performed
1. Import and preprocess the dataset
2. Split data into train/test
3. Train a Linear Regression model
4. Evaluate using MAE, MSE, R²
5. Visualize regression results

## 📁 Dataset
[House Price Dataset on Kaggle](https://www.kaggle.com/datasets/harishkumardatalab/housing-price-prediction)

## 📤 Submission
[Google Form for Submission](https://forms.gle/8Gm83s53KbyXs3Ne9)
